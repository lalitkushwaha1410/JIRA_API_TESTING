package Files;

import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

public class ReusableMethods {
	
	
	 public static String CreateSessionId() {
		  
		  RestAssured.baseURI="http://localhost:8100";
		  Response res= given().headers("Content-Type", "application/json").
		  body("{ \"username\": \"lalitkush1991\", \"password\": \"14101991\" }").when().post("/rest/auth/1/session").
		  then().assertThat().statusCode(200).extract().response();
		  
		    JsonPath js= ReusableMethods.rawToJson(res);
			String sessionid= js.get("session.value");
			System.out.println(sessionid);
			return sessionid;

		  }
	
	 public static XmlPath rawToXML(Response r)
		{
		
			
			String respon=r.asString();
			XmlPath x=new XmlPath(respon);
			return x;
			
		}
		
		
		public static JsonPath rawToJson(Response r)
		{ 
			String respon=r.asString();
			JsonPath x=new JsonPath(respon);
			return x;
		}

		
	
	

}