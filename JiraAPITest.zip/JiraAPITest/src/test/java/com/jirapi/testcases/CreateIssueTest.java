package com.jirapi.testcases;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import Files.ReusableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class CreateIssueTest {
	
	//+GenSessionIdTest.CreateSessionId()
	
	@Test
	public  void CreateIssue() {
		  
		 RestAssured.baseURI="http://localhost:8100";

		 Response res1= given().header("Content-Type", "application/json").
		  header("Cookie","example.cookie.name="+ReusableMethods.CreateSessionId()).
		  body("{\r\n" + 
		  		"\"fields\": {\r\n" + 
		  		"   \"project\":\r\n" + 
		  		"   { \r\n" + 
		  		"      \"key\": \"TEST\"\r\n" + 
		  		"   },\r\n" + 
		  		"   \"summary\": \"REST EXAMPLE\",\r\n" + 
		  		"   \"description\": \"Creating an issue via REST API\",\r\n" + 
		  		"   \"issuetype\": {\r\n" + 
		  		"      \"name\": \"Bug\"\r\n" + 
		  		"   }\r\n" + 
		  		"  }\r\n" + 
		  		"}").when().post("/rest/api/2/issue/").then().extract().response();
		   
		 JsonPath js1 =ReusableMethods.rawToJson(res1);
		 String issueId= js1.get("key");
		 System.out.println(issueId);	 

		 
	}

	
}

