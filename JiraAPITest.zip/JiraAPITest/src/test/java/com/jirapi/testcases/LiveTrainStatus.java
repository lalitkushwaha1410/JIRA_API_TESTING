package com.jirapi.testcases;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import Files.ReusableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class LiveTrainStatus {


	@Test
	public  void FindTrainStatus() {
		  
		 RestAssured.baseURI="https://api.railwayapi.com/v2";
		 		
		 Response res1= given().header("Content-Type", "application/json").
				 when().get("/live/train/12780/date/20-01-2019/apikey/0ifo0kpttl/").then().statusCode(200).extract().response();
		   
		 JsonPath js1 =ReusableMethods.rawToJson(res1);
		 String trainname= js1.get("train.name");
		 System.out.println(trainname);
		 
		 String trainposition= js1.get("position");
		 System.out.println(trainposition);
		
		 String currstnname= js1.get("current_station.name");
		 System.out.println(currstnname);
	
	}
		
}
