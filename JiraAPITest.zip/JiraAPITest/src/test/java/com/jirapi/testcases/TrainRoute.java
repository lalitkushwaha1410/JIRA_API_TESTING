package com.jirapi.testcases;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import Files.ReusableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class TrainRoute {

	
	@Test
	public  void FindTrainRoute() {
		  
		 RestAssured.baseURI="https://api.railwayapi.com/v2";
		 		

		 Response res1= given().header("Content-Type", "application/json").
				 when().get("/route/train/12780/apikey/0ifo0kpttl/").then().statusCode(200).extract().response();
		   
		 JsonPath js1 =ReusableMethods.rawToJson(res1);
		 String trainnumber= js1.get("train.number");
		 System.out.println(trainnumber);	 
	}
	
}
